def summarize_text(text: str) -> str:
    # 🤖 실제 LLM 요약 로직은 여기에 들어갑니다 (예: OpenAI GPT)
    return "CNNs are a type of neural network designed for image processing."  # dummy summary
